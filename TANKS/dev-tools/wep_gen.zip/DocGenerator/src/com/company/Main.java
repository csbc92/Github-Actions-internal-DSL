package com.company;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    private String name;
    private String bundleName;
    private String filePath;

    public Main(String name) {
        this.name = name;
        this.bundleName = "dk.grp1.tanks.weapon." + name;
        this.filePath = bundleName+ "\\src\\main\\java\\dk\\grp1\\tanks\\weapon\\" + name;
        createBundle();
        deleteGenneratedFiles();
        createFiles();
        editPom();
        editBND();
    }

    private void editBND() {
        System.out.println("\n##########################################################");
        System.out.println("Modifying OSGI.bnd");

        List<String> list = new ArrayList<>();

        InputStream is = getClass().getResourceAsStream("/osgi.bnd");
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        String l;

        try {
            while ((l = reader.readLine()) != null) {
                l = l.replace("?", name);
                list.add(l);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Path file = Paths.get(bundleName+"\\osgi.bnd");

        try {
            Files.write(file, list, Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void editPom() {
        System.out.println("\n##########################################################");
        System.out.println("Modifying pom");

        List<String> list = new ArrayList<>();

        InputStream is = getClass().getResourceAsStream("/pom.txt");
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        String l;

        try {
            while ((l = reader.readLine()) != null) {
                l = l.replace(";", name);
                list.add(l);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Path file = Paths.get(bundleName+"\\pom.xml");

        try {
            Files.write(file, list, Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void deleteGenneratedFiles() {
        System.out.println("\n##########################################################");
        System.out.println("Deleting generated files!");

        File pom = new File(bundleName+"\\pom.xml");
        pom.delete();

        File bnd = new File(bundleName + "\\osgi.bnd");
        bnd.delete();

        for (String fileName : filesToDelete) {
            File file = new File(filePath + fileName);
            file.delete();
        }
    }

    private void createBundle() {
        System.out.println("\n##########################################################");
        System.out.println("Creating Bundle!");

        try {
            //ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", "\\"+ System.getenv("MAVEN_HOME") + "\\bin\\mvn.cmd -v");
            ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", " \"" + System.getenv("MAVEN_HOME") + "\\bin\\mvn.cmd\"" + " pax:create-bundle -Dpackage=dk.grp1.tanks.weapon."+name+" -Dname="+name+"-bundle -Dversion=1.0-SNAPSHOT");
            builder.redirectErrorStream(true);
            Process p = builder.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true) {
                line = r.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void createFiles() {
        System.out.println("\n##########################################################");
        System.out.println("Creating new java files");

        for (String fileName : files) {

            List<String> list = new ArrayList<>();

            InputStream is = getClass().getResourceAsStream(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String l;

            try {
                while ((l = reader.readLine()) != null) {
                    l = l.replace("?", name);
                    list.add(l);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            Path file = Paths.get(filePath + "\\internal\\" + fileName.replace("Temp", name).replace("txt", "java").replace("/", ""));

            try {
                Files.write(file, list, Charset.forName("UTF-8"));
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    private final String[] files = new String[]{"/TempWeapon.txt", "/TempActivator.txt", "/Temp.txt", "/TempPlugin.txt"};
    private final String[] filesToDelete = new String[]{"\\ExampleService.java", "\\internal\\ExampleActivator.java", "\\internal\\ExampleServiceImpl.java"};

    public static void main(String[] args) {
        // write your code here
        if (args.length != 0) {
            new Main(args[0]);

        } else {
            System.out.println("No input. Run again and input a Weapon name as parameter!");
        }
    }
}
